package com.example.filtre.enums;

public enum Sexe {
    HOMME,
    FEMME
}
