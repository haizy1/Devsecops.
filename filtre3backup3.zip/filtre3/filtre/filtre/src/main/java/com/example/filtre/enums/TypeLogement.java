package com.example.filtre.enums;

public enum TypeLogement {
    LOGEMENT_ENTIER,
    EN_COLOCATION,
    CHEZ_LHABITANT
}
