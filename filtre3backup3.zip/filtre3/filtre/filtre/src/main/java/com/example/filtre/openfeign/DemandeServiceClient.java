package com.example.filtre.openfeign;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;


@FeignClient(name = "demande-service", url = "http://localhost:1016") // Replace with actual base URL
public interface DemandeServiceClient {

    @GetMapping("/Demande/findAll")
    List<DemandeDTO> findAll();
}
