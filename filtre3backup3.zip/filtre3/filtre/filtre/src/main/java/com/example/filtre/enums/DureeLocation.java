package com.example.filtre.enums;

public enum DureeLocation {
    COURTE, // 1 à 5 mois
    MOYENNE, // 6 à 11 mois
    LONGUE // plusde12mois
}