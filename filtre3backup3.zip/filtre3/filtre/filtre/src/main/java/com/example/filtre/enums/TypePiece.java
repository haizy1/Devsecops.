package com.example.filtre.enums;

public enum TypePiece {
    COULOIR,SALON,TOILETTES,CUISINE,BALCON
}
