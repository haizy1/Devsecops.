package com.example.filtre.openfeign;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DemandeDTO {
    private Integer id;
    private String ville;
    private Integer budgetMensuel;
    private String sexe;
    private String name;
    private String ecole;
    private Boolean possedeDejaLocal;
//    private String typeChambre; // Add typeChambre as a String for readability



    private Integer etudiantId;
    private Integer matchingScore;


    public DemandeDTO(int id, String ville, Integer budgetMensuel, String sexe, String name, String ecole, Boolean possedeDejaLocal,Integer etudiantId,Integer matchingScore) {
        this.id = id;
        this.ville = ville;
        this.budgetMensuel = budgetMensuel;
        this.sexe = sexe;
        this.name = name;
        this.ecole = ecole;
        this.possedeDejaLocal = possedeDejaLocal;
        this.etudiantId = etudiantId;
        this.matchingScore = matchingScore;
//        this.typeChambre = typeChambre;
    }

}

