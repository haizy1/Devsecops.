package com.example.filtre.enums;

public enum Equipement {
    TV,
    WIFI,
    LAVE_LINGE,
    MATERIEL_ENTRETIEN,
    LINGE_MAISON,
    LINGE_LIT
}
