package com.example.filtre.enums;

public enum TypeChambre {
    PARTAGEE, PRIVEE
}