package com.example.filtre.enums;

public enum CuisineEquipement {
    REFRIGERATEUR,
    MICRO_ONDES,
    VAISSELLE,
    PLAQUES_CUISSON,
    FOUR,
    LAVE_VAISSELLE
}
