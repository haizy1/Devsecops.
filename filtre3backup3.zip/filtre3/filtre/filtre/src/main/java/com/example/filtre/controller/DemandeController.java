package com.example.filtre.controller;

import com.example.filtre.openfeign.DemandeDTO;
import com.example.filtre.service.DemandeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class DemandeController {

    private final DemandeService demandeService;

    @Autowired
    public DemandeController(DemandeService demandeService) {
        this.demandeService = demandeService;
    }

    /**
     * Endpoint to filter and calculate matching scores for demandes.
     *
     * @param ville            (optional) The city to filter demandes.
     * @param sexe             (optional) The gender to filter demandes.
     * @param budget           (optional) The budget to filter demandes.
     * @param ecole            (optional) The school to filter demandes.
     * @param possedeDejaLocal (optional) Whether the demande owner has a local.
     * @param name             (optional) The name to filter demandes.
     * @param userId           The user ID to calculate matching scores.
     * @return A list of filtered demandes with their matching scores.
     */
    @GetMapping("/filter/demandes")
    public List<DemandeDTO> filterAndScoreDemandes(
            @RequestParam(value = "ville", required = false) String ville,
            @RequestParam(value = "sexe", required = false) String sexe,
            @RequestParam(value = "budget", required = false) Integer budget,
            @RequestParam(value = "ecole", required = false) String ecole,
            @RequestParam(value = "possedeDejaLocal", required = false) Boolean possedeDejaLocal,
            @RequestParam(value = "name", required = false) String name,
            @RequestParam(value = "userId") int userId
    ) {
        // Call the service to filter and score demandes
        return demandeService.searchAndScoreDemands(ville, sexe, budget, ecole, possedeDejaLocal, name, userId);
    }
}
