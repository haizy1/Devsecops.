package com.example.filtre.openfeign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "matching-service" , url="http://localhost:1018")
public interface MatchingServiceClient {

    @GetMapping("/matching/score")
    int calculateMatchingScore(@RequestParam("userId") int userId, @RequestParam("demandeId") int demandeId);
}
