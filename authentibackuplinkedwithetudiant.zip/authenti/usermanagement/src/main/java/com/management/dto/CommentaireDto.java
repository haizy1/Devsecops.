package com.management.dto;

public class CommentaireDto {
}
