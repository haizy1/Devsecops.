package com.management.enums;

public enum Role {
        ETUDIANT,
        LOUEUR,
        ADMIN

}
