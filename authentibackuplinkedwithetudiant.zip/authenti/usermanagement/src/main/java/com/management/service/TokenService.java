package com.management.service;

import org.springframework.stereotype.Service;

@Service
public class TokenService {

    public boolean isTokenValid(String token) {
        // Implémentation de la validation du token
        return true; // Exemple : renvoyez `true` pour le moment
    }
}
