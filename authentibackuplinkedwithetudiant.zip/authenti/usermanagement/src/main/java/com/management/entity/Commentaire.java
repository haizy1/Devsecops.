package com.management.entity;

public class Commentaire {
}
