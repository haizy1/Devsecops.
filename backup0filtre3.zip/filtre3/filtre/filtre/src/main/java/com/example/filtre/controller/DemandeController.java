package com.example.filtre.controller;

import com.example.filtre.openfeign.DemandeDTO;
import com.example.filtre.service.DemandeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/demandes")
public class DemandeController {

    private final DemandeService demandeService;

    public DemandeController(DemandeService demandeService) {
        this.demandeService = demandeService;
    }

    @GetMapping("/search")
    @CrossOrigin(origins = "http://localhost:3000")
    public ResponseEntity<List<DemandeDTO>> searchDemands(
            @RequestParam(required = false) String ville,
            @RequestParam(required = false) String sexe,
            @RequestParam(required = false) Integer budget,
            @RequestParam(required = false) String ecole,
            @RequestParam(required = false) Boolean possedeDejaLocal,
            @RequestParam(required = false) String name) {
        List<DemandeDTO> demandes = demandeService.searchDemands(ville, sexe, budget, ecole, possedeDejaLocal, name);
        return ResponseEntity.ok(demandes);
    }
}
