package com.example.filtre.service;

import com.example.filtre.openfeign.DemandeDTO;
import com.example.filtre.openfeign.DemandeServiceClient;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DemandeService {

    private final DemandeServiceClient demandeClient;

    public DemandeService(DemandeServiceClient demandeClient) {
        this.demandeClient = demandeClient;
    }

    public List<DemandeDTO> searchDemands(String ville, String sexe, Integer budget, String ecole, Boolean possedeDejaLocal,String name) {
        // Fetch all demandes from the Demande microservice
        List<DemandeDTO> allDemandes = demandeClient.findAll();

        // Apply filtering locally
        return allDemandes.stream()
                .filter(demande -> ville == null || demande.getVille().equalsIgnoreCase(ville))
                .filter(demande -> sexe == null || demande.getSexe().equalsIgnoreCase(sexe))
                .filter(demande -> budget == null || (demande.getBudgetMensuel() >= budget - 500 && demande.getBudgetMensuel() <= budget + 500))
                .filter(demande -> ecole == null || demande.getEcole().equalsIgnoreCase(ecole))
                .filter(demande -> possedeDejaLocal == null || demande.getPossedeDejaLocal().equals(possedeDejaLocal))
                .filter(demande -> name == null || demande.getName().equalsIgnoreCase(name))
                .collect(Collectors.toList());
    }
}
