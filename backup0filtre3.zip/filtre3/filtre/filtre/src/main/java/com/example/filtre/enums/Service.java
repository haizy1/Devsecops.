package com.example.filtre.enums;

public enum Service {
    CONTRAT,
    MENAGE,
    CONCIERGERIE,
    LINGE
}
