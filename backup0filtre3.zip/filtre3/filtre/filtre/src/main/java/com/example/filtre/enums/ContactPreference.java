package com.example.filtre.enums;
public enum ContactPreference {
    HOMMES, FEMMES, PEU_IMPORTE

}

