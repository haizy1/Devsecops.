package com.example.filtre.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;


public enum Cuisine {
    PRIVE,COMMUN
}
