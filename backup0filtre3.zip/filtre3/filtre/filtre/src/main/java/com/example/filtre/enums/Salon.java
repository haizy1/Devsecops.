package com.example.filtre.enums;

public enum Salon {
    PRIVE,COMMUN,AUCUN
}
