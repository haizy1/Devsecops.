package com.example.filtre.enums;

public enum TypeBien {
    MAISON,
    APPARTEMENT,
    STUDIO,
    CHAMBRE
}
