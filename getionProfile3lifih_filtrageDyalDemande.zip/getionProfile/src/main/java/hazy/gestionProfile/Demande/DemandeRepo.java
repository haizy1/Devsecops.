package hazy.gestionProfile.Demande;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DemandeRepo extends JpaRepository<Demande ,Integer> {
}
