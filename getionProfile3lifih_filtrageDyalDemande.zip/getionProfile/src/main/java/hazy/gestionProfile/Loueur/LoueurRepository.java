package hazy.gestionProfile.Loueur;

import org.springframework.data.jpa.repository.JpaRepository;

public interface LoueurRepository extends JpaRepository<Loueur,Integer> {
}
