package hazy.gestionProfile.enumm;

public enum TypeChambre {
    PARTAGEE,
    PRIVEE
}
