package hazy.gestionProfile.enumm;

public enum CuisineEquipement {
    REFRIGERATEUR,
    MICRO_ONDES,
    VAISSELLE,
    PLAQUES_CUISSON,
    FOUR,
    LAVE_VAISSELLE
}
