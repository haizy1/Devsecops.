package hazy.gestionProfile.enumm;

public enum Lifestyle {
    VEGETARIAN,ACTIVE
}
