package hazy.gestionProfile.enumm;

public enum Cuisine {
    PRIVE,COMMUN
}
