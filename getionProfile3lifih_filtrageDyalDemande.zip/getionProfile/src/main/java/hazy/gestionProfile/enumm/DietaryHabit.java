package hazy.gestionProfile.enumm;

public enum DietaryHabit {
    VEGAN,HEALTHY,GLUTEN_FREE
}
