package hazy.gestionProfile.enumm;

public enum TypePiece {
    COULOIR,SALON,TOILETTES,CUISINE,BALCON
}
