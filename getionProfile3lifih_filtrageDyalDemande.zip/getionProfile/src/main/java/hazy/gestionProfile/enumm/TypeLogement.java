package hazy.gestionProfile.enumm;

public enum TypeLogement {
    LOGEMENT_ENTIER,
    LOGEMENT_EN_COLOCATION,
    LOGEMENT_CHEZ_HABITANT
}
