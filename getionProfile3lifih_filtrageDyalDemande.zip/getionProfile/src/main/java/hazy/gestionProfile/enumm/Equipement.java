package hazy.gestionProfile.enumm;

public enum Equipement {
    TV,
    WIFI,
    LAVE_LINGE,
    MATERIEL_ENTRETIEN,
    LINGE_MAISON,
    LINGE_LIT
}
