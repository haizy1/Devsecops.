package hazy.gestionProfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GetionProfileApplicationTests {

	@Test
	void contextLoads() {
	}

}
