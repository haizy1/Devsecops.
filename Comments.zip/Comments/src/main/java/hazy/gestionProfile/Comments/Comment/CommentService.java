package hazy.gestionProfile.Comments.Comment;

import hazy.gestionProfile.Comments.Etudiant.AnnonceClient;
import hazy.gestionProfile.Comments.Etudiant.EtudiantClient;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
@RequiredArgsConstructor
@Service
public class CommentService {
    private final CommentRepository commentRepository;
    private final EtudiantClient etudiantClient;  // FeignClient pour valider l'étudiant
    private final AnnonceClient annonceClient;

    private final KafkaTemplate<String, Comment> kafkaTemplate;


    public Comment creerCommentaire(CommentRequest request) {
        // Valider si l'étudiant existe
        etudiantClient.verifierEtudiant(request.getEtudiantId());

        // Valider si l'annonce existe
        annonceClient.verifierAnnonce(request.getAnnonceId());

        // Créer le commentaire
        Comment commentaire = new Comment();
        commentaire.setEtudiantId(request.getEtudiantId());
        commentaire.setAnnonceId(request.getAnnonceId());
        commentaire.setContenu(request.getContenu());
        commentaire.setDateCreation(LocalDateTime.now());

        Comment savedComment = commentRepository.save(commentaire);

        kafkaTemplate.send("comment-topic", savedComment);

        return savedComment;
    }
}
