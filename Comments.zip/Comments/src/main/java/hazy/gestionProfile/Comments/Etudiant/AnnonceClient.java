package hazy.gestionProfile.Comments.Etudiant;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "annonce-service",url = "http://localhost:1016")
public interface AnnonceClient {
    @GetMapping("/loueur/Annonce/{id}/exists")
    void verifierAnnonce(@PathVariable int id);
}