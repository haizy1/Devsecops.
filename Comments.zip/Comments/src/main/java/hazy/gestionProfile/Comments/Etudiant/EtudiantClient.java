package hazy.gestionProfile.Comments.Etudiant;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "etudiant-service",url = "http://localhost:1016")
public interface EtudiantClient {
    @GetMapping("/etudiant/{id}/exists")
    void verifierEtudiant(@PathVariable int id);
}