package com.example.demo1.enumm;

public enum DureeLocation {
    COURTE, // 1 à 5 mois
    MOYENNE, // 6 à 11 mois
    LONGUE // plus de 12 mois
}

