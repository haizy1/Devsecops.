package com.example.demo1.UsersProfiles;

public enum Sexe {
    HOMME,
    FEMME
}
