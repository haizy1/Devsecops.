package com.example.demo1.enumm;

public enum CuisineEquipement {
    REFRIGERATEUR,
    MICRO_ONDES,
    VAISSELLE,
    PLAQUES_CUISSON,
    FOUR,
    LAVE_VAISSELLE
}
