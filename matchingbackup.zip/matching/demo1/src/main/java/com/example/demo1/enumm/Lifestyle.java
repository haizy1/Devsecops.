package com.example.demo1.enumm;

public enum Lifestyle {
    VEGETARIAN,ACTIVE
}
