package com.example.demo1.enumm;

public enum Salon {
    PRIVE,COMMUN,AUCUN
}
