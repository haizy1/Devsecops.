package com.example.demo1.enumm;

public enum Passion {
    MUSIC,SPORTS
}
