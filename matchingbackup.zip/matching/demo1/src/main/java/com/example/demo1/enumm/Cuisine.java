package com.example.demo1.enumm;

public enum Cuisine {
    PRIVE,COMMUN
}
