package com.example.demo1.enumm;

public enum Service {
    CONTRAT,
    MENAGE,
    CONCIERGERIE,
    LINGE
}
