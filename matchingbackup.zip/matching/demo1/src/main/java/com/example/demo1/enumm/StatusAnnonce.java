package com.example.demo1.enumm;

public enum StatusAnnonce {
    DISPONIBLE, // Bien disponible pour la location
    NON_DISPONIBLE; // Bien non disponible pour d'autres raisons
}
