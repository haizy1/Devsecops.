package com.example.demo1.enumm;

public enum TypeChambre {
    PARTAGEE,
    PRIVEE
}
