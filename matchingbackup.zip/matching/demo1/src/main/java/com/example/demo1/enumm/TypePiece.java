package com.example.demo1.enumm;

public enum TypePiece {
    COULOIR,SALON,TOILETTES,CUISINE,BALCON
}
