package com.example.demo1.enumm;

public enum TypeLogement {
    LOGEMENT_ENTIER,
    LOGEMENT_EN_COLOCATION,
    LOGEMENT_CHEZ_HABITANT
}

