package com.example.demo1.enumm;

public enum TypeBien {
    MAISON,
    APPARTEMENT,
    STUDIO,
    CHAMBRE
}

