package com.example.demo1.enumm;

public enum DietaryHabit {
    VEGAN,HEALTHY,GLUTEN_FREE
}
