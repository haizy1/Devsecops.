package com.example.demo1.UsersProfiles;

public enum ContactPreference {
    HOMMES, FEMMES, PEU_IMPORTE

}
