package hazy.gestionProfile.enumm;

public enum Salon {
    PRIVE,COMMUN,AUCUN
}
