package hazy.gestionProfile.enumm;

public enum TypeBien {
    MAISON,
    APPARTEMENT,
    STUDIO,
    CHAMBRE
}
