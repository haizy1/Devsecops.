package hazy.gestionProfile.enumm;

public enum Service {
    CONTRAT,
    MENAGE,
    CONCIERGERIE,
    LINGE
}
