package hazy.gestionProfile.enumm;

public enum Passion {
    MUSIC,SPORTS
}
